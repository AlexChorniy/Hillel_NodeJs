globalThis.hypotenuse = (cathetOne, cathetTwo) => {
    result = Math.sqrt(cathetOne ** 2 + cathetTwo ** 2);
    return result;
}